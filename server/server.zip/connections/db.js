const mysql = require('mysql');

//create db connection

const db = mysql.createConnection({

     host: "localhost",
    user : "icsmsne6_root",
    port :  3306,
    password : "terminated1234",
    database: "icsmsne6_nppportaldb"
    
});

db.connect((err) => {
    
    if (err) throw err;
     console.log("MySql connected....");
});

module.exports = db;